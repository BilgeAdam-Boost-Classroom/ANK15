﻿using System.Net.Http;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Ödev_A_13
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
           


        }
    }
}
