﻿namespace ANK15TRANSKRİPT.Entity
{
    public interface IEntity
    {
    }
}