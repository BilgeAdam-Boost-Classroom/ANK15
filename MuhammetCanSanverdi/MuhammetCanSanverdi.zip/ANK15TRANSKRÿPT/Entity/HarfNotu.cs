﻿namespace ANK15TRANSKRİPT.Entity
{
    public enum HarfNotu
    {
        AA = 40,
        BA = 35,
        BB = 30,
        CB = 25,
        CC = 20,
        DC = 15,
        DD = 10,
        FD = 5,
        FF = 0
    }
}