﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ANK15Burger.Entity.Concrete.Enum
{
    public enum Boyut
    {
        Küçük,
        Orta,
        Büyük
    }
}
