﻿using System;
using System.Collections.Generic;

namespace NorthwindDBFirst.Models
{
    public partial class Urunler1
    {
        public string ProductName { get; set; } = null!;
        public string? CategoryName { get; set; }
    }
}
