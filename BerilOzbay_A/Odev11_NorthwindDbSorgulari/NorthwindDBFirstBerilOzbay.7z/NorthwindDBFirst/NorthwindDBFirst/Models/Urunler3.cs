﻿using System;
using System.Collections.Generic;

namespace NorthwindDBFirst.Models
{
    public partial class Urunler3
    {
        public string? ProductName { get; set; }
        public string? CategoryName { get; set; }
    }
}
