﻿using System;
using System.Collections.Generic;

namespace NorthwindDBFirst.Models
{
    public partial class Urunler4
    {
        public string ProductName { get; set; } = null!;
    }
}
