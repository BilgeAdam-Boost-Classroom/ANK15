﻿using System;
using System.Collections.Generic;

namespace NorthwindDBFirst.Models
{
    public partial class Urunler2
    {
        public string? ProductName { get; set; }
        public string CategoryName { get; set; } = null!;
    }
}
