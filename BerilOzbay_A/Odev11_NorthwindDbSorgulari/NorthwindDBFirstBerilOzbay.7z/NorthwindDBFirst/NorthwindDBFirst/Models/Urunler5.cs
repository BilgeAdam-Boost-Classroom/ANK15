﻿using System;
using System.Collections.Generic;

namespace NorthwindDBFirst.Models
{
    public partial class Urunler5
    {
        public string CategoryName { get; set; } = null!;
    }
}
