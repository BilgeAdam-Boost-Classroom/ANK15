﻿using Microsoft.EntityFrameworkCore;
using NorthwindDBFirst.Models;

namespace NorthwindDBFirst
{
    internal class Program
    {
        static void Main(string[] args)
        {
            NORTHWNDEnglishContext _db = new NORTHWNDEnglishContext();

            //string Ad, Soyad;
            //int id;

            //Console.WriteLine("Adinizi giriniz:");
            //Ad =  Console.ReadLine();

            //Console.WriteLine("Soyadinizi giriniz:");
            //Soyad = Console.ReadLine();

            //Employee yeniCalisan = new Employee();
            //yeniCalisan.FirstName = Ad;
            //yeniCalisan.LastName = Soyad;

            //_db.Employees.Add(yeniCalisan);
            //_db.SaveChanges();

            //Console.WriteLine("Basari ile kaydedilmistir.");

            //Console.WriteLine("Guncellenecek calisananın id'sini giriniz: ");
            //id = Convert.ToInt32(Console.ReadLine());

            //var guncellenecekCalisan = _db.Employees.FirstOrDefault(e => e.EmployeeId == id);

            //Console.WriteLine("Adinizi giriniz:");
            //guncellenecekCalisan.FirstName = Console.ReadLine();

            //Console.WriteLine("Soyadinizi giriniz:");
            //guncellenecekCalisan.LastName = Console.ReadLine();

            //_db.SaveChanges();

            //Console.WriteLine("Silinecek calisananın id'sini giriniz: ");
            //id = Convert.ToInt32(Console.ReadLine());

            //var silinecekCalisan = _db.Employees.FirstOrDefault(e => e.EmployeeId == id);

            //_db.Employees.Remove(silinecekCalisan);

            //_db.SaveChanges();

            // gorev1
            //foreach(var item in _db.Employees) 
            //{
            //    Console.WriteLine(item.FirstName + ' ' + item.LastName);
            //}

            ////gorev2
            //foreach (var employee in _db.Employees.Where(e => e.FirstName.StartsWith("A")))
            //{
            //    Console.WriteLine("Employee Name: " + employee.FirstName + "Employee LastName: " + employee.LastName);
            //}
            //// gorev3
            //foreach (var employee in _db.Employees.Where(a => a.FirstName.Contains("A")))
            //    Console.WriteLine(employee.FirstName + employee.LastName);
            ////gorev4
            //foreach (var item in _db.Products.Where(p => p.UnitPrice == _db.Products.Max(m => m.UnitPrice)).ToList())
            //{
            //    Console.WriteLine(item.ProductName);
            //}
            ////gorev5
            //var minUnitPriceProuct = _db.Products.ToList().MinBy(p => p.UnitPrice);
            //var result4 = _db.Products.Where(p => p.UnitPrice == minUnitPriceProuct.UnitPrice).Select(p => new Product { ProductName = p.ProductName });

            //foreach (var item in result4)
            //{
            //    Console.WriteLine(item.ProductName);
            //}

            ////7
            //var sonunucu = _db.Employees.ToList().LastOrDefault();
            //Console.WriteLine(sonunucu.FirstName + " " + sonunucu.LastName);


            ////8
            //var ilk = _db.Employees.ToList().FirstOrDefault();
            //Console.WriteLine(ilk.FirstName + " " + ilk.LastName);


            ////9
            //var aranan1 = _db.Employees.OrderBy(e => e.BirthDate).FirstOrDefault();
            //Console.WriteLine(aranan1.FirstName + " " + aranan1.LastName);


            ////10
            //var aranan2 = _db.Employees.OrderByDescending(e => e.BirthDate).LastOrDefault();
            //Console.WriteLine(aranan2.FirstName + " " + aranan2.LastName);


            ////11
            //foreach (var item in _db.Employees.Where(e => e.Address.Contains("House") || e.TitleOfCourtesy == "Dr."))
            //{
            //    Console.WriteLine(item.TitleOfCourtesy + " " + item.FirstName + " " + item.LastName + " " + item.Address);
            //}

            ////12
            //foreach (var item in _db.Employees.Where(e => e.FirstName == "Andrew"))
            //{
            //    Console.WriteLine(item.FirstName + " " + item.LastName + " " + item.Address);
            //}

            ////13
            //var aranan3 = _db.Employees.FirstOrDefault(e => e.FirstName.StartsWith("A"));
            ////var aranan4 = _db.Employees.Where(e => e.FirstName.StartsWith("A")).FirstOrDefault();


            //Console.WriteLine(aranan3.FirstName + " " + aranan3.LastName + " " + aranan3.BirthDate);


            //Console.WriteLine("----------------------------------------------");
            ////14

            //foreach (var item in _db.Products.Where(p => p.UnitPrice > _db.Products.Average(p => p.UnitPrice)))
            //{
            //    Console.WriteLine(item.ProductName + "  " + item.UnitPrice);
            //}

            //ODEVLER-----------------------------------------------------------------

            //Soru1:

            //foreach (var customer in _db.Customers.OrderBy(c => c.ContactName))
            //{
            //    Console.WriteLine(customer.ContactName);
            //}

            //Soru2:
            //foreach (var customer in _db.Customers.Where(c => c.Fax == null))
            //{
            //    Console.WriteLine(customer.ContactName + " " + customer.Phone);
            //}

            //Soru3:
            //foreach (var customer in _db.Customers
            //    .Where(c => (c.City == "Berlin" && c.ContactTitle == "Sales Representative") || (c.Country == "Canada" && c.Region == "BC"))
            //    .OrderByDescending(c => c.CustomerId))
            //{
            //    Console.WriteLine(customer.ContactName + " " + customer.ContactTitle + " " + customer.Country + " " + customer.City + " " + customer.Region);
            //}

            //Soru4:
            //var ulkesiİspanyaOlanlar = _db.Customers.Count(c => c.Country == "Spain");

            //Console.WriteLine($"İspanya'da bulunan müşteri sayısı: {ulkesiİspanyaOlanlar}");

            //Soru5:
            //var ulkesiUSAOlanlar = _db.Customers.Count(c => c.Country == "USA");
            //var sehriLondonOlanlar = _db.Customers.Count(c => c.Country == "London");

            //Console.WriteLine($"Aralarındaki kişi sayisi farki:  {ulkesiUSAOlanlar - sehriLondonOlanlar} ");

            //Soru6:
            //var ortalama = _db.OrderDetails.Average(o => o.Quantity);
            //Console.WriteLine(ortalama);

            //Soru7:
            //var maxPrice = _db.OrderDetails.ToList().OrderBy(o => o.OrderId).MaxBy(p => p.UnitPrice);
            //Console.WriteLine("Urun Id: " + maxPrice.OrderId);

            //Soru8:
            //var minPrice = _db.OrderDetails.ToList().OrderByDescending(o => o.OrderId).MinBy(p => p.UnitPrice);
            //Console.WriteLine("Urun Id: " + minPrice.OrderId);

            //Soru9:
            //var totalPrice = _db.OrderDetails.Where(o => o.OrderId >= 10400 && o.OrderId <= 10450).Sum(o => o.UnitPrice);
            //Console.WriteLine(totalPrice);

            //Soru10:
            //var toplam = _db.OrderDetails.Where(o => o.Quantity % 3 == 0 && o.Quantity % 5 != 0).Sum(o => o.Quantity);
            //Console.WriteLine(toplam);
        }
    }
}