namespace Miray_Cemre_Tuncel_Ödev2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Add what is written on the text box into the combox and write it to listbox
            comboBox1.Items.Add(textBox1.Text);
            listBox1.Items.Add(textBox1.Text);
            //then you need to clear the text box for the next item to be added
            textBox1.Clear();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex != -1)
            {
                MessageBox.Show("The item chosen from ListBox is:  " + listBox1.SelectedItem);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(comboBox1.SelectedIndex != -1)
            {
                MessageBox.Show("The item chosen from ListBox is:  " + comboBox1.SelectedItem);
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            //when clicked on this button set index to -1
            listBox1.SelectedIndex = -1;
            comboBox1.SelectedIndex = -1;
        }
    }
}