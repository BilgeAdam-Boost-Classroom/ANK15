﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Odev4
{
    public class Canli
    {
     
        public string Ad { get; set; }

        public int Yas { get; set; }
        public string SesCikar()
        {
            return "ses ses";
        }

    }
}
