﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Odev4
{
    public class Kedi:Canli
    {

        public string SesCikar()
        {
            return "miyav miyav";
        }

    }
}
